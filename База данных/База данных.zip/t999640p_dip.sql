-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июл 02 2019 г., 23:13
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `t999640p_dip`
--

-- --------------------------------------------------------

--
-- Структура таблицы `access_tokens`
--
-- Создание: Апр 10 2019 г., 11:09
-- Последнее обновление: Июл 02 2019 г., 19:43
--

DROP TABLE IF EXISTS `access_tokens`;
CREATE TABLE `access_tokens` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `access_tokens`
--

INSERT INTO `access_tokens` (`id`, `admin_id`, `token`) VALUES
(1, 1, 'access8d4b0c19673a2ac3e9990052a88c8312'),
(2, 1, 'accessd2ba4ae290e42f0812162cc195e125a1'),
(3, 1, 'accessdac33fef42ff33cf04dabbe94fbf499d'),
(4, 2, 'access453bc464635135ca6e27458bde67b30b'),
(5, 1, 'access8b4cca60c7e51e489748d75075710dd0'),
(6, 1, 'access0c391a660331ce293d00950ad49576f8'),
(7, 1, 'accessd3de02004ca74bda33d981886ba59a75'),
(8, 1, 'access749b6090dbc8d6c61773acdaf8bf4024'),
(9, 2, 'access0688914ac4981e97aa464e67601085b7'),
(10, 2, 'access37d166a75e5407aa04bb72f8d497fe6b'),
(11, 2, 'access2a8ab2e4b1268ea19e5fcc32f0a38cab'),
(12, 2, 'accessb6499937124e5f9cefc15b494ff96327'),
(13, 2, 'access6f64b990b4f7d3dec0c3f6f2acf3c8fb'),
(14, 2, 'access7d05a502a7bfd15911d78d90692fe986'),
(15, 1, 'access4f960eccf8a29670334bc782de416c62'),
(16, 2, 'accessd2aefdea3235d7f50e1a1abb14a61eec'),
(17, 1, 'access2848cd258b0f281c0eb806fa029703fc'),
(18, 1, 'accessf794ff72718d236f395ea5539ae50d6f'),
(19, 3, 'access6c4a81f1e66025a72a6430a41ce00f76'),
(20, 1, 'access13bc531710fd2a4d9027575413c84fc8'),
(21, 2, 'accessfe1564b33de59301f23d57b6cce42696'),
(40, 2, 'accessd715ccada26cdae40b301a43d8e385bd'),
(41, 1, 'access3740a73a8302f9d5ef9a66b59ab28c4c'),
(42, 2, 'access06e2e84ea6652a1452a18cb3b6e620d4'),
(43, 1, 'accessdbdab7f0fd817bb4384b140d9af57416'),
(44, 7, 'access7326e8fdb1cfeade2bb877979080984d'),
(45, 1, 'accessd1a1b4c0ebdc4456c2f2489a694df1ec'),
(46, 7, 'access9a24023473af784c2ba1f2c3f8b59a79'),
(47, 1, 'access5150ad15ccc09d633280824bcac1d216'),
(48, 2, 'access1cbe969003395a88990282d107b11f0c'),
(49, 1, 'access73e984b623a8043bb7b84c700e839a03'),
(50, 2, 'accessbd203dc44d95a16c4c9acd0248684984'),
(51, 2, 'accessd6f5531f4ae2a6c51e6e863025b39612'),
(52, 2, 'access0a061ae24cb2834d0d14aab74b7c7272'),
(53, 2, 'access1db3ec7a4e8efdd7066f0c7d2fffa023'),
(54, 2, 'accessaf39a42ac0467e074c9755c4cfe0bb51'),
(55, 2, 'access37154b615cdee306b0df70627d27878d'),
(56, 2, 'access495bfe85c642996b4dedb85caa5dfb1f'),
(57, 2, 'accessa82c443cc678850acae48f725d0a76d3'),
(58, 2, 'access6c4ade47ee43f389e9ba1571d17d9b98'),
(59, 2, 'access8855ce6537f929d92e7a27019922a6fa'),
(60, 2, 'access6d7557ad1145983f3507d3dd8d6dede3'),
(61, 2, 'access0fd647be36ff994ad4c7263f60184739'),
(62, 2, 'accessfaaef15d66161bfa2d345614d5415d2b'),
(63, 2, 'accessa32f4958a59c670c4886982a7f70f0fc'),
(64, 2, 'access0f8cc386b3ca7d304ac0567ed7540cfd'),
(65, 2, 'access8a0efd90a3d5bfe4f30c25370a1d573a'),
(66, 2, 'access32ee64717ee964fad0b15b1c83249d3d'),
(67, 2, 'access33ffb74b35b5b7f58929bcd3bea5b978'),
(68, 1, 'accesseb31d32a831b6325233b9f7a197fa8cd'),
(69, 2, 'accessc6a8a31e1e11e1155c7ad062b816dfca'),
(70, 1, 'access2d8ef4bb69a958467460fb53b91cf3d9'),
(71, 2, 'access34b754e6d1a6999d53f5e1d90b1fd439'),
(72, 2, 'access7a6985bdb95dab59468aa083a6fa0830'),
(73, 2, 'accessfaed0bedcbd8c4ac5f77e48cf9cd7f67'),
(74, 2, 'accessa8a12b554d8f62055d542304466ad94d'),
(75, 2, 'access79896e5a65c2ad60813420c0f27ca1e8'),
(76, 2, 'accessae0a2d96aaa7d6906210c3ce5e8dcadf'),
(77, 2, 'access0bd10deaf0cbac40e46af4a994abcf3d'),
(78, 2, 'access74bbf4aaa02f7fb9834637a4eff98a35'),
(79, 2, 'accessb13dc1baaee871f3835548b6fecb7562'),
(80, 2, 'accessb13dc1baaee871f3835548b6fecb7562'),
(81, 2, 'access81331852f90525f51eaf0a881f8dabc4'),
(82, 2, 'accessd482625cea74791774907208373f09a7'),
(83, 2, 'access9501a54bfb1bf1eea9d4bacdad836f04'),
(84, 2, 'access9c00e7f68a9932cee54af0ad28ff532d'),
(85, 2, 'access354311fac84c67bcebdcd1eba8c840df'),
(86, 2, 'accessfa1661084e4a2ea3cf4ed66057dd5593'),
(87, 2, 'access7e740d9c835b7e9a2b9ef478cfedc0bc'),
(88, 2, 'accessbe9ac84487a07b762b64886c7287d104'),
(89, 2, 'accessec99e3d64fe093a2a57913d2d27f9fa7'),
(90, 2, 'accessa0f56959612ad5e80f660a72da00e7ef'),
(91, 2, 'access6b2901774aa174ae360e5df39e7af331'),
(92, 2, 'access665fff9c8d52a9af3bf1d6ca1b4df7fc'),
(93, 2, 'accessacc59c37bfa417a943f74279a4a2695b'),
(94, 2, 'access2d971fdd1368d004ba1d46663e1f1258'),
(95, 2, 'access8aeab8ba1f093c4b8e8687e3f90facaf'),
(96, 2, 'access160d4c5838e7842cc7b7926e726b92fd'),
(97, 2, 'accessbc814bb2f5d7c1759c2400f8be197f4a'),
(98, 2, 'accessefa49605978bc41465ef4f8dd87d388b'),
(99, 2, 'accesseacde357181f09937442a0aec5a37e52'),
(100, 2, 'accesseacde357181f09937442a0aec5a37e52'),
(101, 2, 'accessc14ca7e8f400bd3cee2c443ecbac1754'),
(102, 2, 'accesse4ab54e254d53451e5e65ce40fa5293f'),
(103, 2, 'access75c8aea5be5b85cf760c924109d8df4e'),
(104, 2, 'access71b63ed425d7d09641d0ecebc049a42d'),
(105, 2, 'access4c585bb6ad2dac79ee34c01e047ae268'),
(106, 2, 'access077f4584aefd6cac0d1614a6d016f0b3'),
(107, 2, 'accessa7a25b51103a461a9bdabcfda57bc788'),
(108, 2, 'accesse9b3c004795e2485eb77377364ffe439'),
(109, 2, 'access04542447b53f1b67e871d5a733b9289a'),
(110, 2, 'access93863da46d8d55e923680ef5854c0fef'),
(111, 2, 'access8b2f7496d9f3fd3a5b68dea03883c101'),
(112, 1, 'access2b59ac98a5ae28ffc04cab1409674b4c'),
(113, 2, 'access9070aae46faa35bb2aa2a2a89a5b545b'),
(114, 2, 'access3f410e9290e135b7ffd4d2b343dfe5db'),
(115, 2, 'access36824241fd8211e5579f026fde64bf9f'),
(116, 2, 'access50bc1d022eb7a4df4c851f3ad40db294'),
(117, 2, 'access23f6ccab8bba61ad7723b7be96a18200'),
(118, 2, 'accessdf7ce7dcb118f9119bcb7dcfbd3d2acb'),
(119, 2, 'accessc3273d00983ee5059508b2e5cfa7f92c'),
(120, 2, 'access194627087ced81a36135a9bfbedb3a58'),
(121, 2, 'accesse819e53d5a46a3a2e15e37a14c221a42'),
(122, 2, 'access88558230c4a0cb0e6e7807b6593d249d'),
(123, 2, 'access4456f93e505cc716dcbc91b9b5690a20'),
(124, 2, 'access9a81073c10334f32837b12e4b7396aeb'),
(125, 2, 'access75f991fd9021f32d3ce262aa4fe8e85a'),
(126, 2, 'access63a96017ab17466f4df19b7b8742fc43'),
(127, 2, 'accessa2f899b5be4dea51aaa3777f57075589'),
(128, 2, 'access924ac7c159a40cabfbcc8482f0a11e31'),
(129, 2, 'access2007fb2bbaa835980f16d5d0b7f8d934'),
(130, 1, 'access6d9a2288682ebde3d18b316366bf1586'),
(131, 1, 'accessc866adb3b26e9b008768989784a9983b'),
(132, 1, 'access0b702f25fbd00e60237bf584614f1220'),
(133, 1, 'accessada450d477800fe092d1378448c7df77'),
(134, 1, 'access2c346f5ddf51381ab9dceeea6e20b115'),
(135, 2, 'access7d815bb350eb70ba9f57c0653bdd4fcc'),
(136, 2, 'access1c01ae1c11ffaa3b5839a332aca6176a'),
(137, 1, 'accesseddee070cfda3d248b6d0ad6bc5989b6'),
(138, 1, 'accesscc21c22c7bbdcf7f9dd62ac56f95b5f9'),
(139, 2, 'access8874e4d51c0ed6f97a52757bc15cef1a'),
(140, 1, 'access2c65a8217bff3d2de6da838c4bbe0e1d'),
(141, 2, 'access01293c3de0395e013bf475620a16229a'),
(142, 2, 'access061f1a2b147a6aa18189a5b3019af27d'),
(143, 2, 'access063a6e96895f56e3b1c056864b23aefc'),
(144, 2, 'access6889807f4d45945aa2b8b5242ad7a2b3'),
(145, 2, 'access769981bfc91b03f0116bcbca6734eb68'),
(146, 2, 'accessb4e4a5ce84637d3acb339a4b6ff5cd70'),
(147, 2, 'access87ef2b4d3cc0a5eb8effc9f3cf910580'),
(148, 2, 'access098eeaa5f54b189784119586def5fef7'),
(149, 2, 'accessb6fe020c70e180ab23afe137baff541c'),
(150, 2, 'access49261d87ad5a64960e02fe1b152c501e'),
(151, 2, 'access1095c26fe262158e5bfa2090869e70a2'),
(152, 2, 'access65cc4864773e90a2bb7d2275e1f21429'),
(153, 2, 'access482301abac3424758b66c9d360b9e2b3'),
(154, 2, 'access34e9e46ca54736fccbafd85acf0c54f7'),
(155, 2, 'access6317f41d93374e5a201250ee7580b9a8'),
(156, 2, 'access19707421bced7ef93dbf02461c2adb74'),
(157, 2, 'access81ee8437a107c98190e7a4ec831c8b8b'),
(158, 2, 'access697332c21de353873cd1b382b0739339'),
(159, 2, 'access0ccce4643ab76a792416815fe1f9b3f5'),
(160, 2, 'accesscc5e004230735dd1f1c08b156e11829b'),
(161, 2, 'accessc1c8bac2a795417c8a67cc1e6adfcda8'),
(162, 2, 'access8146a7e3ccbf62ce66a19db0d16b379f'),
(163, 2, 'access5afa7d113c73a08d6573025531071ef8'),
(164, 2, 'accessfab52f8e5e4c3fedbad3a868121372dd'),
(165, 2, 'accessd701af8bfd27a314912848989dc1fa4b'),
(166, 2, 'access77109322300cb6b2fdc69ea926f8108e'),
(167, 2, 'access91caf028bb93a4ce6ecb99769d30b768'),
(168, 2, 'accessf90d00d7dd5c3d515820c2d925177310'),
(169, 2, 'access67a6cf2c033e60ced24eab20df627398'),
(170, 2, 'access70bb051442b9bb420323a52120d10ab3'),
(171, 2, 'access369a6f6480a946bf7285c5eaf95cfd1c'),
(172, 2, 'access751634b2fc7fa1bf6c7659e28b3cea0e'),
(173, 2, 'access16aec72f1364b0064f6e888a465b016a'),
(174, 2, 'accesse2a9159ccdca1a396cc82b437d9b95c2'),
(175, 2, 'access6fef58962176bf14add33845f5abc2a7'),
(176, 1, 'accessa761b26d2865d7e5486e08704028e1e6'),
(177, 2, 'accessa20878b9cd3615763568478a1657803b'),
(178, 2, 'access3538d76364a8819834826a18936810af'),
(179, 2, 'access1389f2c993853ab1baf647e237aa7662'),
(180, 2, 'access1f3fb1d3f334ef3d899e6e8646fd4799'),
(181, 2, 'access3eaf54c6d77cb43b6ab2e69011e4702b'),
(182, 2, 'access435a0b668387821c7e666a6bf3d4f494'),
(183, 2, 'access4d2052953bc791bba1bf661139f78f72'),
(184, 2, 'access3bba00f5ce0791615932428e5db8533d'),
(185, 2, 'access2f531fa71d6f2819e6b8246bf91cf7a2'),
(186, 2, 'access72835fb437c232dd6f0484bf2da1a471'),
(187, 2, 'access69c6b282b6ae5a8f719550eb1b5e5424'),
(188, 2, 'accessd9baea055f79964f463cb8671bc2c71b'),
(189, 2, 'access45f3d310de39544d42acc387c069c9ce'),
(190, 2, 'access5fb262a3a1aeaee31b3660ede2c39dbe'),
(191, 2, 'accessc7f472c03a9de189c6a1239639581661'),
(192, 2, 'accesse620530d683783e37e19af7c26ee0443'),
(193, 1, 'access6bbefd23edb9a45c9adf6ede891b56a3'),
(194, 2, 'access92d214d91d001f1cf93eefd74ff74fae'),
(195, 1, 'access9bb7ccf6b9ac147d6ec265af6f812c80'),
(196, 3, 'accessb84a4c05c46ac2ae651af4f71ba2bb1d'),
(197, 9, 'access69399f26112e09caf3ad5d2e0cf2ac0e'),
(198, 2, 'accessdfe592b450306721dfcadd25f206743a'),
(199, 2, 'accessd585d96d4e53da21e585db73ed664b72'),
(200, 2, 'accesse0ebc62db4412be7430614c14cd167ee'),
(201, 2, 'access0e048ef2f353416aff39ec537a047905'),
(202, 2, 'access5cd517e408aab3f7bc375353a3c624e6'),
(203, 2, 'access0abfb1c5eeea89cb61c261a8a4ff2e18'),
(204, 2, 'access338c397a378be7256095fdf2910d847e'),
(205, 2, 'access4a3ba7488792f60abc1c25995d7711fd'),
(206, 2, 'access4a3ba7488792f60abc1c25995d7711fd'),
(207, 2, 'access92977a7386b05bc5eca00b11ac5d44e8'),
(208, 2, 'access352ea447924d966a1784f04a15709c05'),
(209, 2, 'access2e2982d51b10d1040fc30f3217b08e13'),
(210, 2, 'access030891ca73c00cebf06acb32437b2edb'),
(211, 2, 'accessaa3cc858bcfd0c47c30a5ad31a5d2a85'),
(212, 2, 'accessa42b890330c63542040c9d2545efc20c'),
(213, 2, 'accessa9d87f78dbbd16a9e553d194026ce91f'),
(214, 2, 'accessb0c0a95075dbd583e999d0dee89cf685'),
(215, 2, 'accessad518974970b756af450a02962ffacf2'),
(216, 2, 'access59c9788bea94fc1d278ec2a1160e385e'),
(217, 2, 'access00ff520aaac07046bf134d7482f1ec54'),
(218, 2, 'access09efc1eabb0360f1a3ca464ce5dd94a1'),
(219, 2, 'accessd47b07ac2bd1f0a0bbca43adcb1191d4'),
(220, 2, 'access71c6671798ef7313596dc1764671b079'),
(221, 2, 'access5d312178b7545eb5eea9eb7e986c61ea'),
(222, 2, 'access3c8ef8df88cb5e9a2b744060973b3a9e'),
(223, 2, 'access5b75582db225bd08c7cafeebb3c1ff3c'),
(224, 2, 'accessc3ca93e6bddeeb11b6d8bae803057291'),
(225, 2, 'access692bf6be9ec3aacdc2f8830b1eeb6806'),
(226, 2, 'access080007f5a88528e3321d1d63adff6d6b'),
(227, 2, 'accessab48585f7fbdb6d333ddeb9ae0d48bf7'),
(228, 2, 'accessab48585f7fbdb6d333ddeb9ae0d48bf7'),
(229, 2, 'access2cdcf4b313846f9eb8c6bba197c63f88'),
(230, 2, 'accessb8b12f12c6fed809425ad10e4b10e2ab'),
(231, 2, 'access862a72489fc38474c794f91fbde25562'),
(232, 2, 'accessc20e50bf7086dacfae935ce5fbc6c70f'),
(233, 2, 'accessaa6f7520bc390f22915aed17e2ffde93'),
(234, 2, 'access2027a11f4f6f477edc2f0a40f2fc9ea2'),
(235, 2, 'access6bb14fa4c00e53c6d8c1c5bdef67993f'),
(236, 2, 'accessb74f742c303f799fd8b6d0fb9e8b3b77'),
(237, 2, 'access72a8f164b1f06ec19f9f67edbb516477'),
(238, 2, 'access48219ae64e56d4b97dfd9210634d1d3d'),
(239, 2, 'accesse67e9e222f9bf6787e8d35d8daffc849'),
(240, 2, 'accessb07afb475f35cd841d2302a997ed7c15'),
(241, 2, 'access26495e79c897f93128e91fc7d4e9a140'),
(242, 2, 'accesse720508f9de7422023a44a546ca24f80'),
(243, 9, 'access7f1a090a2b717fea343e332540a020aa'),
(244, 10, 'accessa8df781dddf6816209fed5610be3d986'),
(245, 2, 'access42c200de934430fb1db1d25296a48370'),
(246, 2, 'access42c200de934430fb1db1d25296a48370'),
(247, 9, 'accessb9624591103c17e75049caf7fb9786c4'),
(248, 2, 'access69a39c42bfd3ae92428f6210cb87c459'),
(249, 2, 'access0fccb47bbd22810875553e1484d498da'),
(250, 2, 'accessdc5d44b4e6d11decd2f0b6b6bf7b23ec'),
(251, 2, 'access2284e1e4da5a18ee94cc030310e581ec'),
(252, 2, 'access261b9045bcc2a1a934f78418df803056'),
(253, 2, 'accessdbc2d964c36bffb98977ad86bdabc59b'),
(254, 2, 'access683eaf8db798e297a9508fcd9ddf4eab'),
(255, 2, 'access14b92a58220f56bc5d8c33535a5ef9be'),
(256, 2, 'accessc10d2362747f30a838b8f14fa25225d6'),
(257, 2, 'accessfff64a123fc75c7276ea675a68501ddc'),
(258, 9, 'accessa4630900fe70261041142971d009f41d'),
(259, 11, 'access54790311efa29997cf2531e7cd32385c'),
(260, 9, 'access178d6c8f015308bd6ea42dc030991203'),
(261, 11, 'access64bf948b42cf70661017bcf2552f82c3'),
(262, 2, 'access3ab7c897b70f4c070765c649fce9d057'),
(263, 2, 'access6662dc96255c0d57d8affd70b70be432'),
(264, 2, 'access373decdc4140bf536aed91723619b13d'),
(265, 2, 'accessf81180a35d319374012534bc78c060d9'),
(266, 9, 'accessbe5bc416f1470a92796d3711f5d713ce'),
(267, 2, 'accessacf7537713c95e269ea3d016dc4ae1ee'),
(268, 9, 'access7e128c075b7856dbd23c85563f563974'),
(269, 9, 'access4d43b701fbd984fe570b99bb034dc004'),
(270, 11, 'accessb9fa2dcfe0bf0de710ed2b5d042e2769'),
(271, 2, 'access88b2aa55dd1fa9f1a77dac6255599d06'),
(272, 9, 'access0c9358bc744f6a65a409e64c16c094d1'),
(273, 2, 'accessa85cee935248e0c14a81573a24b1c778'),
(274, 9, 'access02239e6f85dd704678df9ce23d55c153'),
(275, 2, 'access49c7799d71bac93ba6faaf40f2b6a526');

-- --------------------------------------------------------

--
-- Структура таблицы `admins`
--
-- Создание: Апр 10 2019 г., 11:09
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `super_user` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `admins`
--

INSERT INTO `admins` (`id`, `login`, `password`, `name`, `email`, `super_user`) VALUES
(0, 'null', 'null', 'нет данных', '', 0),
(2, 'asuadmin', 'b1469224af591e16c1e7a0234f13167b', 'AsuAdmin', 'asu@edu.ru', 0),
(3, 'apes', '4f16aeeec0e9c4ef2477bfd120576407', 'Алихан Пешхоев', 'al.pes@bk.ru', 1),
(7, 'kirill', '4f16aeeec0e9c4ef2477bfd120576407', 'Кирилл Яйков', 'kirill', 0),
(9, 'admin', 'b1469224af591e16c1e7a0234f13167b', 'Super Admin', 'non@mail.com', 1),
(10, 'demo', '4f16aeeec0e9c4ef2477bfd120576407', 'Тестовый пользователь', 'demo@mail.ru', 0),
(11, 'operator', '4f16aeeec0e9c4ef2477bfd120576407', 'Operator', 'operator@bk.ru', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `admins_buildings`
--
-- Создание: Апр 10 2019 г., 11:09
-- Последнее обновление: Июл 02 2019 г., 19:30
--

DROP TABLE IF EXISTS `admins_buildings`;
CREATE TABLE `admins_buildings` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `admins_buildings`
--

INSERT INTO `admins_buildings` (`id`, `admin_id`, `building_id`) VALUES
(24, 7, 10),
(26, 10, 3),
(30, 11, 3),
(31, 11, 10),
(32, 2, 3),
(33, 2, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `buildings`
--
-- Создание: Апр 10 2019 г., 11:09
--

DROP TABLE IF EXISTS `buildings`;
CREATE TABLE `buildings` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `city_id` int(11) NOT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `buildings`
--

INSERT INTO `buildings` (`id`, `title`, `city_id`, `address`) VALUES
(3, 'АГУ (тест)', 2, 'Татищева 21а'),
(4, 'МГУ (тест)', 1, NULL),
(10, 'БГУ', 5, '');

-- --------------------------------------------------------

--
-- Структура таблицы `cities`
--
-- Создание: Апр 10 2019 г., 11:09
--

DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `country_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cities`
--

INSERT INTO `cities` (`id`, `title`, `country_id`) VALUES
(1, 'Москва', 1),
(2, 'Астрахань', 1),
(5, 'Берлин', 2),
(6, 'Мюнхен', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `countries`
--
-- Создание: Апр 10 2019 г., 11:09
--

DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `countries`
--

INSERT INTO `countries` (`id`, `title`) VALUES
(1, 'Россия'),
(2, 'Германия'),
(3, 'Япония');

-- --------------------------------------------------------

--
-- Структура таблицы `points`
--
-- Создание: Май 18 2019 г., 17:58
-- Последнее обновление: Июл 02 2019 г., 17:54
--

DROP TABLE IF EXISTS `points`;
CREATE TABLE `points` (
  `id` int(11) NOT NULL,
  `device_id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `building_id` int(11) NOT NULL,
  `edited_by` int(11) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `points`
--

INSERT INTO `points` (`id`, `device_id`, `title`, `building_id`, `edited_by`, `last_update`) VALUES
(8, '13', 'A', 10, 7, '2019-04-10 15:46:07'),
(23, 'F4:B8:5E:B6:13:D7', 'перекрёсток', 4, 2, '2019-06-27 21:50:11'),
(24, '78:A5:04:1E:58:60', 'аудитория 405', 4, 2, '2019-06-27 21:50:29'),
(25, '1C:BA:8C:29:EC:74', 'аудитория 404', 4, 2, '2019-06-27 20:58:36'),
(26, 'C8:FD:19:12:DA:DF', 'кафедра информационных технологий', 4, 2, '2019-06-27 21:50:43'),
(27, 'B4:99:4C:52:AF:D4', 'главный вход', 4, 2, '2019-06-27 21:49:54');

-- --------------------------------------------------------

--
-- Структура таблицы `points_aliases`
--
-- Создание: Апр 10 2019 г., 11:09
--

DROP TABLE IF EXISTS `points_aliases`;
CREATE TABLE `points_aliases` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `point_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `points_aliases`
--

INSERT INTO `points_aliases` (`id`, `title`, `point_id`) VALUES
(4, 'кабинет 703', 26),
(5, 'лаборатория', 24),
(6, 'развилка', 23),
(7, 'ресепшон', 27),
(8, 'пустая аудитория', 25);

-- --------------------------------------------------------

--
-- Структура таблицы `vectors`
--
-- Создание: Апр 10 2019 г., 11:15
-- Последнее обновление: Июл 02 2019 г., 19:05
--

DROP TABLE IF EXISTS `vectors`;
CREATE TABLE `vectors` (
  `id` int(11) NOT NULL,
  `building_id` int(11) NOT NULL,
  `start_point` int(11) NOT NULL,
  `end_point` int(11) NOT NULL,
  `distance` int(11) NOT NULL,
  `direction` int(11) NOT NULL,
  `edited_by` int(11) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `vectors`
--

INSERT INTO `vectors` (`id`, `building_id`, `start_point`, `end_point`, `distance`, `direction`, `edited_by`, `last_update`) VALUES
(20, 4, 27, 23, 5, 1, 2, '2019-06-29 09:28:32'),
(21, 4, 23, 27, 5, 180, 2, '2019-06-29 09:28:47'),
(22, 4, 23, 24, 4, 90, 2, '2019-06-29 09:29:05'),
(23, 4, 24, 23, 4, 270, 2, '2019-06-29 09:29:29'),
(24, 4, 23, 25, 6, 270, 2, '2019-06-29 09:29:47'),
(25, 4, 25, 23, 6, 90, 2, '2019-06-29 09:29:55'),
(26, 4, 25, 26, 5, 1, 2, '2019-06-29 09:30:47'),
(27, 4, 26, 25, 5, 180, 2, '2019-07-02 19:05:41');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `access_tokens`
--
ALTER TABLE `access_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `admins_buildings`
--
ALTER TABLE `admins_buildings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admins_buildings_fk0` (`admin_id`),
  ADD KEY `admins_buildings_fk1` (`building_id`);

--
-- Индексы таблицы `buildings`
--
ALTER TABLE `buildings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `buildings_fk0` (`city_id`);

--
-- Индексы таблицы `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cities_fk0` (`country_id`);

--
-- Индексы таблицы `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `points`
--
ALTER TABLE `points`
  ADD PRIMARY KEY (`id`),
  ADD KEY `points_fk0` (`building_id`);

--
-- Индексы таблицы `points_aliases`
--
ALTER TABLE `points_aliases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `points_aliases_fk0` (`point_id`);

--
-- Индексы таблицы `vectors`
--
ALTER TABLE `vectors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vectors_fk0` (`start_point`),
  ADD KEY `vectors_fk1` (`end_point`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `access_tokens`
--
ALTER TABLE `access_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=276;

--
-- AUTO_INCREMENT для таблицы `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `admins_buildings`
--
ALTER TABLE `admins_buildings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT для таблицы `buildings`
--
ALTER TABLE `buildings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `points`
--
ALTER TABLE `points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT для таблицы `points_aliases`
--
ALTER TABLE `points_aliases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `vectors`
--
ALTER TABLE `vectors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `admins_buildings`
--
ALTER TABLE `admins_buildings`
  ADD CONSTRAINT `admins_buildings_fk0` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `admins_buildings_fk1` FOREIGN KEY (`building_id`) REFERENCES `buildings` (`id`);

--
-- Ограничения внешнего ключа таблицы `buildings`
--
ALTER TABLE `buildings`
  ADD CONSTRAINT `buildings_fk0` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`);

--
-- Ограничения внешнего ключа таблицы `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `cities_fk0` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`);

--
-- Ограничения внешнего ключа таблицы `points`
--
ALTER TABLE `points`
  ADD CONSTRAINT `points_fk0` FOREIGN KEY (`building_id`) REFERENCES `buildings` (`id`);

--
-- Ограничения внешнего ключа таблицы `points_aliases`
--
ALTER TABLE `points_aliases`
  ADD CONSTRAINT `points_aliases_fk0` FOREIGN KEY (`point_id`) REFERENCES `points` (`id`);

--
-- Ограничения внешнего ключа таблицы `vectors`
--
ALTER TABLE `vectors`
  ADD CONSTRAINT `vectors_fk0` FOREIGN KEY (`start_point`) REFERENCES `points` (`id`),
  ADD CONSTRAINT `vectors_fk1` FOREIGN KEY (`end_point`) REFERENCES `points` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
